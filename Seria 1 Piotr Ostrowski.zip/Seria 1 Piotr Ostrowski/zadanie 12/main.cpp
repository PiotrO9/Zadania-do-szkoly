#include <iostream>

using namespace std;

int main()
{
    float n1,n2,n3;
    cout << "Podaj 1 wymiar: " << endl;
    cin>>n1;
    cout << "Podaj 2 wymiar: " << endl;
    cin>>n2;
    cout << "Podaj 3 wymiar: " << endl;
    cin>>n3;

    cout<< "Objetosc wynosi: " << n1 * n2 * n3 << endl;
    return 0;
}
