#include <iostream>

using namespace std;

int main()
{
    int a,b,c;

    cout << "Podaj 1 liczbe: " << endl;
    cin >> a;
    cout << "Podaj 2 liczbe: " << endl;
    cin>>b;
    cout << "Podaj 3 liczbe: " << endl;
    cin>>c;

    cout << "Twoja srednia to: "<<(a+b+c)/3 <<endl;

    return 0;
}
