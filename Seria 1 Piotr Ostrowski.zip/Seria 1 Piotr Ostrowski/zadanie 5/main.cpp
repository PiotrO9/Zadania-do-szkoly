#include <iostream>

using namespace std;

int main()
{
    int g,m,s;

    cout << "Podaj ilosc godzin: " << endl;
    cin>>g;
     m = g *60;
     s = m * 60;

    cout<<"Ilosc minut: "<<m<<endl;
    cout<<"Ilosc sekund: "<<s<<endl;
    return 0;
}
