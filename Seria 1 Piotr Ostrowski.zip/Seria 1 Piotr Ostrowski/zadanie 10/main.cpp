#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float r,o,p;
    cout << "Podaj promien: " << endl;
    cin>>r;
    cout<<"Pole wynosi: "<<r*r*M_PI<<endl;
    cout<<"Obwod wynosi: "<<2*r*M_PI<<endl;
    return 0;
}
