#include <iostream>

using namespace std;

int pierwiastkowanie2(int l);
int pierwiastkowanie3(int l);

int main()
{
    int n1;

    cout << "Podaj liczbe: " << endl;
    cin>>n1;


    cout<<"Podana liczba do potegi 2 to: "<<pierwiastkowanie2(n1)<<endl;
    cout<<"Podana liczba do potegi 3 to: "<<pierwiastkowanie3(n1)<<endl;

    return 0;
}

pierwiastkowanie2(int l)
{
    return l*l;
}

pierwiastkowanie3(int l)
{
    return l*l*l;
}
