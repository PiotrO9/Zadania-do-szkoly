#include <iostream>

using namespace std;

int main()
{
    int t,k;
    cout << "Podaj ilosc trojkatow: " << endl;
    cin>>t;
    cout << "Podaj ilosc kwadratow: " << endl;
    cin>>k;

    cout<<"Potrzebna ilosc cekinow do ozdobienia wynosi: "<<t*3+k*4<<endl;

    return 0;
}
