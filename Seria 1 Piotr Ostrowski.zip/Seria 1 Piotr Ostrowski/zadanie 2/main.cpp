#include <iostream>

using namespace std;

int main()
{
    int rok;

    cout << "Podaj swoj rok urodzenia: " << endl;
    cin >> rok;

    cout << "Masz " << 2020 - rok<< " lat" << endl;
    return 0;
}
