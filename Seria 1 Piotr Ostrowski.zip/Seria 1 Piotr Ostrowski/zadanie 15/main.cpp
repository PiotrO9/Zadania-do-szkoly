#include <iostream>

using namespace std;

int main()
{
    float t;
    cout << "Podaj liczbe tygodni" << endl;
    cin >>t;

    cout<<"liczba tygodni przeliczona na miesiace: "<< t/4 <<endl;
    cout<<"liczba tygodni przeliczona na dni: "<< t*7 <<endl;
    return 0;
}
