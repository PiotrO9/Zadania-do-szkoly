#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a,o;
    cout << "Podaj liczbe: " << endl;
    cin>>a;
    cout <<"Pierwiastek z podanej liczby to: "<< sqrt(a)<<endl;
    o = 1/a;
    cout <<"Odwrotnosc podanej liczby to: "<< o;
    return 0;
}
