#include <iostream>

using namespace std;

int main()
{
    int s;
    float h,m;
    cout << "Podaj liczbe minut: " << endl;
    cin>>m;

    h = m/60;
    s = m*60;

    cout<<"Liczba minut przeliczona na godziny: "<<h<<endl;
    cout<<"Liczba sekund przeliczona na godziny: "<<s<<endl;
    return 0;
}
