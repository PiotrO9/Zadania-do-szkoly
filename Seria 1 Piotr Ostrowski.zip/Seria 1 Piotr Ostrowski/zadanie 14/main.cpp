#include <iostream>

using namespace std;

int main()
{
    float KB,B,b;
    cout << "Podaj liczbe bajtow: " << endl;
    cin>>B;

    KB = B/1024;
    b = B*8;

    cout << "Liczba bajtow przeliczona na KB: "<< KB <<endl;
    cout << "Liczba bajtow przeliczona na b: "<< b <<endl;
    return 0;
}
