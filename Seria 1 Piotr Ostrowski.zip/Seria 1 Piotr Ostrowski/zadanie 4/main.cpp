#include <iostream>

using namespace std;

int main()
{
    int d,k;

    cout << "Podaj dlugosc rury kupionej w hurtowni: " << endl;
    cin >>d;
    cout << "Podaj dlugosc odcinka,  na jaki ma byc pocieta rura: " << endl;
    cin >>k;

    cout<<"Ilosc krotkich rur: "<<d/k;

    return 0;
}
