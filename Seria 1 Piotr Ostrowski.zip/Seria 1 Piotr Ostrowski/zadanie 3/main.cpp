#include <iostream>

using namespace std;

int main()
{
    float a,h;
    cout << "Podaj dlugosc boku trojkata: " << endl;
    cin >> a;
    cout << "Podaj wysokosc trojkata: " << endl;
    cin >> h;

    float wynik;
    wynik = (a*h)/2;

    cout<<"Pole powierzchni trojkata to: "<<wynik <<endl;
    return 0;
}
