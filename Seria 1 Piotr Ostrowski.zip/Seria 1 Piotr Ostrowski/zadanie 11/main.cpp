#include <iostream>

using namespace std;

int main()
{
    int m,h,s;
    cout << "Podaj liczbe minut: " << endl;
    cin >> m;

    h=m/60;
    s=m-(h*60);
    cout << "Liczba godzin wynosi: "<< h <<endl;
    cout << "Liczba sekund wynosi: "<< s <<endl;
    return 0;
}
