#include <iostream>

using namespace std;

float obliczanie(float n,int w);

int main()
{
    int w1,w2;
    float n1,n2,wynik;

    cout << "Podaj 1 liczbe" << endl;
    cin>> n1;
    cout << "Podaj wage pierwszej liczby" << endl;
    cin>>w1;

    cout << "Podaj 2 liczbe" << endl;
    cin>> n2;
    cout << "Podaj wage drugiej liczby" << endl;
    cin>>w2;

    wynik = (obliczanie(n1,w1) + obliczanie(n2,w2))/(w1+w2);

    cout<<"Srednia arytmetyczna z podanych liczb to: "<<wynik <<endl;

    return 0;
}

float obliczanie(float n,int w)
{
    return n*w;
}
